<?php
/*
* Sidebar Area.
*/

?>

<?php dynamic_sidebar( 'sideber-1'); ?>